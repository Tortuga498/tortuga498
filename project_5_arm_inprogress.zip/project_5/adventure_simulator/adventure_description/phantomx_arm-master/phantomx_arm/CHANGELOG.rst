^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package phantomx_arm
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2017-02-26)
------------------
* First indigo release based upon turtlebot_arm package
