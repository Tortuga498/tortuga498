#!/usr/bin/env python
import rospy, pcl_ros, tf
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Point
from visualization_msgs.msg import MarkerArray, Marker
from nav_msgs.msg import OccupancyGrid, Odometry
from tf.transformations import euler_from_quaternion

import cv2, math, pcl
import numpy as np

grid = OccupancyGrid()
grid.header.frame_id = 'odom'
grid.info.resolution = 0.05
grid.info.width = 400
grid.info.height = 400
grid.info.origin.position.x = -10.0
grid.info.origin.position.y = -10.0
grid.info.origin.orientation.w = 1.0
grid.data = [-1] * (400 * 400)

pub1 = rospy.Publisher('/scan', LaserScan, queue_size = 10)
pub2 = rospy.Publisher('/map', OccupancyGrid, queue_size = 10)

def current_coordinate() :
    global tfListener
    global choise

    ready = False
    while not ready :
        try:
            if choise:
                (position, orientation) = tfListener.lookupTransform('/odom', '/base_footprint', rospy.Time(0))
            else:
                (position, orientation) = tfListener.lookupTransform('/odom_visual', '/base_footprint', rospy.Time(0))

            ready = True
        except :
            ready = False
            continue
    (x, y, _) = position
    (_, _, theta) = tf.transformations.euler_from_quaternion(orientation)  
    return x, y, theta 


def laser_callback(msg):
    (x0, y0, th0) = current_coordinate()
    amin = msg.angle_min
    amax = msg.angle_max
    ainc = msg.angle_increment
    dmin = msg.range_min
    dmax = msg.range_max
    arr = list(msg.ranges)

    a = th0 + amin
    for i in range(len(arr)):
        if (not math.isnan(arr[i])) and (arr[i] >= amin) and (arr[i] <= amax):
            b = (a + math.pi) % (2 * math.pi) - math.pi
            x1 = x0 + arr[i] * math.cos(b)
            y1 = y0 + arr[i] * math.sin(b)

            p0 = to_grid(x0, y0, self.origin_x, self.origin_y, self.size_x, self.size_y, self.resolution)
            p1 = to_grid(x1, y1, self.origin_x, self.origin_y, self.size_x, self.size_y, self.resolution)
            if p0 <> None and p1 <> None:
                (gx0, gy0) = p0
                (gx1, gy1) = p1
                ps = bresenham(gx0, gy0, gx1, gy1)
                for (gx, gy) in ps:
                    self.grid.data[to_index(gx, gy, self.size_x)] = 0
                if arr[i] < dmax:
                    self.grid.data[to_index(gx1, gy1, self.size_x)] = 100
            else:
                print "out of range"
        a += ainc 
    pub1.publish(msg)     
    pub2.publish(grid)


def main():
    global tfListener
    global choise

    rospy.init_node('adventure_map', anonymous=True)

    choise = True
    #if rospy.has_param('/use_odom'):
    #    if rospy.get_param('/use_odom') == True:
    #        choise = True lasan

    tfListener = tf.TransformListener()
    rospy.Subscriber("/scan", LaserScan, laser_callback)
    rospy.spin()


if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
